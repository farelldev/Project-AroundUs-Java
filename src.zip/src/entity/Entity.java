package entity;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Entity {
    public int x, y;
    public int speed;

    public BufferedImage up1, up2, down1, down2, right1, right2, left1, left2;
    public String direction;

    // --- TAMBAHAN UNTUK COLLISION ---
    public Rectangle solidArea;
    public boolean collisionOn = false;
}

   

